# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["HealthResponse"]


class HealthResponse(BaseModel):
    """Health check response body"""

    status: str

    version: str
